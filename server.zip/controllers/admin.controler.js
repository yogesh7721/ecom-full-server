const asyncHandler = require("express-async-handler")
const Product = require("../model/Product")

//  Products
exports.getAllProducts = asyncHandler(async (req, res) => {
    constresult = await Product.find()
    res.json({ message: "Prodcut fetch Success", result })
})
exports.addProducts = asyncHandler(async (req, res) => {
    await Product.create(req.body)
    res.json({ message: "Prodcut Add Success" })
})
exports.updateProducts = asyncHandler(async (req, res) => {
    res.json({ message: "Prodcut Update Success" })
})
exports.deleteProducts = asyncHandler(async (req, res) => {
    res.json({ message: "Prodcut Delete Success" })
})
exports.deactivateProducts = asyncHandler(async (req, res) => {
    res.json({ message: "Prodcut Deactivate Success" })
})
exports.activateProducts = asyncHandler(async (req, res) => {
    res.json({ message: "Prodcut Activate Success" })
})
exports.getProductDetails = asyncHandler(async (req, res) => {
    res.json({ message: "Prodcut Details Fetch Success" })
})


// Order
exports.getAllOrders = asyncHandler(async (req, res) => {
    res.json({ message: "Order Fetch Success" })
})
exports.getAllOrderDetails = asyncHandler(async (req, res) => {
    res.json({ message: "Order Details Fetch Success" })
})
exports.cancelOrder = asyncHandler(async (req, res) => {
    res.json({ message: "Order cancel Success" })
})
exports.updateOrderStatus = asyncHandler(async (req, res) => {
    res.json({ message: "Order status update Success" })
})


// Users
exports.getAllUsers = asyncHandler(async (req, res) => {
    res.json({ message: "User fetch Success" })
})
exports.getUserdetails = asyncHandler(async (req, res) => {
    res.json({ message: "User detail fetch Success" })
})
exports.blockUser = asyncHandler(async (req, res) => {
    res.json({ message: "User block Success" })
})
exports.unblockUser = asyncHandler(async (req, res) => {
    res.json({ message: "User un-Block Success" })
})
exports.getUserOrders = asyncHandler(async (req, res) => {
    res.json({ message: "User order Fetch Success" })
})
